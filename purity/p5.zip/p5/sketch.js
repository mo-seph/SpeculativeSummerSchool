// SERIAL CONNECTION VARIABLES
let serial;
let latestData = "waiting for data";

// TEACHABLE MACHINE VARIABLES

// const modelURL = "https://teachablemachine.withgoogle.com/models/0fKTsO4rx/"; // This is the model made by the team
const modelURL = "https://teachablemachine.withgoogle.com/models/YRVeU9S7S/"; // this is my model for testing

const classes = ["empty", "object"];
let counter = 0;
let classifier;
let video;
let flippedVideo;
let label;
let conf;
let isSure = false;
const incrementVal = 0.01;
let lastTime = 0;

function preload() {
  // Load the image classifier model (a.k.a. the created AI)
  classifier = ml5.imageClassifier(modelURL + "model.json");
}

function setup() {
  createCanvas(640, 260);
  video = createCapture(VIDEO);
  video.size(320, 260);
  video.hide();
  setupSerial();
  frameRate(30);
  flippedVideo = ml5.flipImage(video); // Video needs to be flipped
  classifyVideo(); // Capture video and start classifying it.
  lastTime = millis();
  background(0);
}

function draw() {
  // update the counter every frame
  if (label == "object" && conf > 0.9) {
    counter += incrementVal;
  } else {
    counter -= incrementVal;
  }

  if (counter > 1) {
    counter = 1; // Set to upper limit if it exceeds 1
  }
  if (counter < 0) {
    counter = 0; // Set to lower limit if it exceeds 0
  }

  // TODO - every second update the background color based on the counter
  if (millis() - lastTime > 300) {
    let r = map(counter, 0, 1, 255, 0); // Red decreases from 255 to 0
    let g = 0; // Green stays 0
    let b = map(counter, 0, 1, 0, 255); // Blue increases from 0 to 255
    // Set the background color based on the counter
    const colorCode = `${r}:${g}:${b}`;
    background(r, g, b);

    console.log(`${r}:${g}:${b}`);
    // serial.write(colorCode);
    lastTime = millis();
  }

  // fill the background with the color based on counter
  fill(255);

  image(flippedVideo, 0, 0); // Add the video currently being classified to the left side of the screen

  textSize(16);
  textAlign(CENTER);
  // text(`${label} | ${counter}`, (3 * width) / 4, height - 4); // Add text with what the AI classifies the video as on the bottom right side of the screen
}

function classifyVideo() {
  flippedVideo = ml5.flipImage(video);
  // Make the classifier view the video and call the function "gotResult" with the result.
  classifier.classify(flippedVideo, gotResult);
  flippedVideo.remove();
}

function gotResult(error, results) {
  if (error) {
    // If an error occurs, print it in the console.
    console.error(error);
    return;
  }

  label = String(results[0].label); // This is the result of the AI
  conf = Number(results[0].confidence); // This is the confidence of the AI in the result

  classifyVideo(); // Classify the next image in the video.
}

function gotData(currentString) {
  // If currentString is empty, this if statement will return "true" and exit the gotData function. Empty variables are 'falsy' values. You can read more about this on this page: https://developer.mozilla.org/en-US/docs/Glossary/Falsy
  if (!currentString) return;
  //console.log(currentString);
  console.log(`serial data: ${currentString}`);
}
